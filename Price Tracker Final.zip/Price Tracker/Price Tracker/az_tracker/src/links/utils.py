import requests
import lxml
from bs4 import BeautifulSoup

def get_link_data(url):
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68",
        "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8"
    }

    response = requests.get(url, headers=headers)

    soup = BeautifulSoup(response.text, "lxml")

    name = soup.select_one(selector="#productTitle").getText()
    name = name.strip()

    uc_price = soup.select_one(selector=".a-price-whole").getText()
    def clean_string(s):
        cleaned = ''.join(filter(lambda x: x.isdigit() or x == '.', s))
        return float(cleaned)

    s = uc_price
    price = clean_string(s)
    
    return name, price